//все редюсеры которые будут в приложении будем импортировать сюда
// и одной пачкой от сюда экспортировать
import auth from './auth'
import event from './event';
export default {
    auth,
    event
}